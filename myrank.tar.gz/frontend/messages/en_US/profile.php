<?php
return [
    'Рейтинг' => 'Rating',
];