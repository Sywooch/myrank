<div class="b-modal__header">
    <?= $model->title ?>
</div>
<div class="b-modal__content">
    <div class="row">
    <img src="<?= $model->name ?>" />
    </div>
    <div class="row">
	<?= $model->description ?>
    </div>
</div>