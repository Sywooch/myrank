<div class="modal fade" id="modalView" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
	<button type="button" class="modal-close" data-dismiss="modal"></button>
	<div class="modal-content">

	    <div class="b-modal">
		<form action="#">
		    <div class="b-modal__header">
			<!-- title -->
		    </div>
		    <div class="b-modal__content">
			<!-- content -->
		    </div>
		</form>
	    </div>
	</div>
    </div>
</div>
