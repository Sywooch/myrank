<?php

return [
    'CREATE'=>'Створити',
    'UPDATE'=>'Оновити',
    'DELETE'=>'Видалити',
    'CREATED_AT'=>'Створити',
    'UPDATED_AT'=>'Змінити',
    'SEARCH'=>'Знайти',
    'RESET'=>'Скинути',
    'ARE_YOU_SURE_DELETE_ITEM'=>'Ви впевнені що хочете видалити цю річ?',
    'CITIES'=>'Міста',
    'CREATE_CITY'=>'Додати місто',
    'UPDATE_CITY'=>'Оновити місто'
];
